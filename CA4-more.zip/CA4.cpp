#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <sstream>
#include <cstdlib>     /* srand, rand */
#include <algorithm>
#include <ctime>
/*****
	encasement : 1..10
	Graph nodes : 1..200
****/

#define num_of_chromosomes 100
//#define init_randomness 100000
#define mutation_randomness	70
#define time_limit 10
#define RISK_LIMIT 10
using namespace std;

 
vector < vector <int> > Graph;
int num_of_encasement=0;
int total_num_of_pairs=0;		/*unique pairs*/	
vector < vector<int> > chromosomes;
vector <int> fitness_val;

void print_vec(vector < int > vec);
void get_graph();
string int_to_string(int num);
vector<int> generate_random_chromosome();
vector<int> generate_random_vector(int min,int max);
void generate_init_chromosomes();
vector <int> generate_monotonous_chromosome(int i);
int max_fitness();
void fitness_fn();
void print_vec_2dim(vector <vector<int> > vec);
vector < vector<int> > reproduce(int idx1,int idx2);
vector <int> random_selection();
void mutate(vector <int> &child);
int genetic_algorithm();
void intelligent_initiator();

int genetic_algorithm_2();
int search_answer();

int main()
{
	get_graph();
	cout<<"Enter your guess for number of encasements : ";
	cin>>num_of_encasement;
	 generate_init_chromosomes();
	// //intelligent_initiator();
	 print_vec_2dim(chromosomes);
	 fitness_fn();
	int bestScore=0;
	
	bestScore=genetic_algorithm();
	cout<<"Desired Score :"<<total_num_of_pairs/2<<endl;
	cout<<"Best Chromosome: "<<endl;

	cout<<"Score : "<<bestScore<<endl;

	//int i=num_of_encasement;

	//int bestNumIdx=max_fitness();
	//int bestFitnessScore=fitness_val[bestNumIdx];
	//vector<int> best_fitness=chromosomes[bestNumIdx];
	// while(num_of_encasement<200)
	// {
	// 	cout<<num_of_encasement<<endl;
	// 	idx=genetic_algorithm();

	// 	if(fitness_val[idx]==total_num_of_pairs)
	// 	{
	// 		break;
	// 	}
	// 	else if(fitness_val[idx]>bestFitnessScore)
	// 	{
	// 		bestFitnessScore=fitness_val[idx];
	// 		best_fitness=chromosomes[idx];
	// 	}
	// 	num_of_encasement++;
	// }
	// print_vec(best_fitness);
	// cout<<"Desired Score :"<<total_num_of_pairs<<endl;
	// cout<<"Score : "<<bestFitnessScore<<endl;
	// cout<<"!!!!!!!!!!!!!!"<<endl;
	// print_vec(chromosomes[0]);
	// mutate(chromosomes[0]);
	// print_vec(chromosomes[0]);
	// mutate(chromosomes[1]);
	// print_vec(chromosomes[0]);
	//print_vec(fitness_val);
	//print_vec(random_selection());
	
	

}

vector <int> random_selection()
{

	vector <int> tmp(num_of_chromosomes,0);
	
	int sum=0;
	int percentage=0;
	for(int i=0;i<fitness_val.size();i++)
	{
		sum+=fitness_val[i];
	}
	
	int idx=0;
	for(int i=0;i<fitness_val.size();i++)
	{
		percentage=(int)( ( ( (float)fitness_val[i]/sum )*num_of_chromosomes)+0.5);
		//cout<<"percentage : "<<percentage<<"VS. "<<( ( ( (float)fitness_val[i]/sum )*100))<<endl;
		int j=idx;
		for(j=idx;j<percentage+idx && j<num_of_chromosomes;j++)
		{
			tmp[j]=i;
		}
		idx=j;
	}
	
	std::random_shuffle ( tmp.begin(), tmp.end() );

	vector<int> nums(tmp.begin(), tmp.begin()+num_of_chromosomes);

	return tmp;
}
int genetic_algorithm()
{

	vector <int> selections=random_selection();

	vector < vector <int> > child;
	int randProbability1,randProbability2;
	vector < vector <int> > new_chromosomes;
	clock_t begin = clock();
	clock_t end = clock();
	int iteration=0;
	double elapsed_secs= double(end - begin) / CLOCKS_PER_SEC;
	int max_score=0;
	vector <int> best_fitness;
	while(elapsed_secs<time_limit)
	{
		//cout<<"-->ITERATION : "<<iteration<<endl;
		iteration++;
		new_chromosomes.clear();
		for(int i=0;i<selections.size();i+=2)
		{
			child=reproduce(selections[i],selections[i+1]);
			randProbability1=rand() % 100 ;
			randProbability2=rand() % 100 ;
		//	cout<<"randProbability : "<<randProbability1 <<", "<<randProbability2<<endl;
			if(randProbability1<mutation_randomness){
				//cout<<"****MUT****"<<endl;
				//print_vec_2dim(child);
				mutate(child[0]);
				//print_vec_2dim(child);
	
			}
			if(randProbability2<mutation_randomness){
				//cout<<"****MUT****"<<endl;
				//print_vec_2dim(child);
				mutate(child[1]);
				//print_vec_2dim(child);

			}
			new_chromosomes.push_back(child[0]);
			new_chromosomes.push_back(child[1]);
		}
	
		chromosomes=new_chromosomes;
		fitness_fn();
		int max_fit_idx=max_fitness();
		if(total_num_of_pairs/2-fitness_val[max_fit_idx]<RISK_LIMIT)
		{
			return fitness_val[max_fit_idx];
		}
		else if(fitness_val[max_fit_idx]>max_score){
			max_score=fitness_val[max_fit_idx];
			best_fitness=chromosomes[max_fit_idx];
		}
		//print_vec(fitness_val);

		end = clock();
		elapsed_secs = double(end - begin) / CLOCKS_PER_SEC;
		
	}

	return max_score;


	
}
int search_answer()
{
	int initial_num_of_encasement=num_of_encasement;
	generate_init_chromosomes();
	//intelligent_initiator();
	print_vec_2dim(chromosomes);
	fitness_fn();
	int score;
	score=genetic_algorithm_2();
	int answer=0;
	if(score== total_num_of_pairs/2)
	{
		int i=initial_num_of_encasement;
		answer=i;
		while(i>=0 && score==total_num_of_pairs/2)
		{
			i--;
			cout<<i<<endl;
			num_of_encasement=i;
			chromosomes.clear();
			fitness_val.clear();
			generate_init_chromosomes();
			fitness_fn();
			score=genetic_algorithm_2();
			
		}
		answer=i+1;
	}
	else
	{
		cout<<"HEHE"<<endl;
		int i=initial_num_of_encasement;
		while(i<=200 && score!=total_num_of_pairs/2)
		{
			i++;
			cout<<i<<endl;
			num_of_encasement=i;
			chromosomes.clear();
			fitness_val.clear();
			generate_init_chromosomes();
			fitness_fn();
			score=genetic_algorithm_2();
		}
		answer=i;
	}
	return answer;
}

int genetic_algorithm_2()
{

	vector <int> selections=random_selection();

	vector < vector <int> > child;
	int randProbability1,randProbability2;
	vector < vector <int> > new_chromosomes;
	clock_t begin = clock();
	clock_t end = clock();
	int iteration=0;
	double elapsed_secs= double(end - begin) / CLOCKS_PER_SEC;
	int max_score=0;
	vector <int> best_fitness;
	while(elapsed_secs<time_limit)
	{
		//cout<<"-->ITERATION : "<<iteration<<endl;
		iteration++;
		new_chromosomes.clear();
		for(int i=0;i<selections.size();i+=2)
		{
			child=reproduce(selections[i],selections[i+1]);
			randProbability1=rand() % 100 ;
			randProbability2=rand() % 100 ;
		//	cout<<"randProbability : "<<randProbability1 <<", "<<randProbability2<<endl;
			if(randProbability1<mutation_randomness){
				//cout<<"****MUT****"<<endl;
				//print_vec_2dim(child);
				mutate(child[0]);
				//print_vec_2dim(child);
	
			}
			if(randProbability2<mutation_randomness){
				//cout<<"****MUT****"<<endl;
				//print_vec_2dim(child);
				mutate(child[1]);
				//print_vec_2dim(child);

			}
			new_chromosomes.push_back(child[0]);
			new_chromosomes.push_back(child[1]);
		}
	
		chromosomes=new_chromosomes;
		fitness_fn();
		int max_fit_idx=max_fitness();
		if(total_num_of_pairs/2-fitness_val[max_fit_idx]<RISK_LIMIT)
		{
			return fitness_val[max_fit_idx];
		}
		else if(fitness_val[max_fit_idx]>max_score){
			max_score=fitness_val[max_fit_idx];
			best_fitness=chromosomes[max_fit_idx];
		}
		//print_vec(fitness_val);

		end = clock();
		elapsed_secs = double(end - begin) / CLOCKS_PER_SEC;
		
	}

	return max_score;


	
}



void intelligent_initiator()
{
	int j=1;
	srand(time(NULL));
	for(int i=0;i<num_of_chromosomes;i++)
	{
		vector <int> tmp;
		if(i%2==0)
		{

			int randNum;

			for(int k=0;k<Graph.size();k++){
				randNum=rand() % num_of_encasement + 1;
		
				tmp.push_back(randNum);
			}
			chromosomes.push_back(tmp);
			fitness_val.push_back(0);
		}
		else
		{
		
			for(int k=0;k<Graph.size();k++){
		
				tmp.push_back(j);
			}
			chromosomes.push_back(tmp);
			fitness_val.push_back(0);
			j++;
		}
		
	}
}

void mutate(vector <int> &child)
{
	int randChoice = rand() % 2;
/*	if(randChoice==0)
	{
		int randIdx=rand() % Graph.size() ;
		int randNum= rand() % num_of_encasement + 1;
		//cout<<"Rand Idx: "<<randIdx<<" Rand num: "<<randNum<<endl;
		
		child[randIdx]=randNum;
	}*/
	//if(randChoice==0)
//	{
		
		int numOfMut=rand() % child.size()+1;
		for(int i=0;i<numOfMut;i++){
			int randIdx=rand() % Graph.size();
			int randNum=rand() % num_of_encasement +1;
			child[randIdx]=randNum;
		}
	//}
	/*else if(randChoice==1 )
	{
		int randNum=rand() % num_of_encasement +1;
		int numOfMut=rand() % child.size()+1;
		for(int i=0;i<numOfMut;i++)
		{
			int randIdx=rand() % Graph.size();
			child[randIdx]=~child[randIdx];
		}
	}*/
	/*
	else 
	{
		int randIdx=rand() % Graph.size() ;
		int randNum=rand() % num_of_encasement + 1;
		child[randIdx]=randNum;
	}*/
	/*else if(randChoice==1)
	{
		for(int i=0;i<child.size();i++)
		{
			
			child[i]=num_of_encasement;
		}
	}*/

	
}

int max_fitness()
{
	int max=fitness_val[0];
	int maxIdx=0;
	for(int i=0;i<fitness_val.size();i++)
	{
		if(fitness_val[i]>max){
			max=fitness_val[i];
			maxIdx=i;
		}
	}
	return maxIdx;
}

vector < vector<int> > reproduce(int idx1,int idx2)
{
	vector < vector<int> > result;

	int n=chromosomes[idx1].size();
	
	int randNum=rand() % n + 1;
	//Scout<<"RAND : "<<randNum<<endl;
	vector<int>::const_iterator first1 = chromosomes[idx1].begin();
	vector<int>::const_iterator last1 = chromosomes[idx1].begin() + randNum;
	vector<int> firstChromosome1(first1, last1);
	
	vector<int>::const_iterator first2 = chromosomes[idx2].begin() +randNum;
	vector<int>::const_iterator last2 = chromosomes[idx2].end();
	vector<int> secondChromosome1(first2, last2);
	

	vector<int> child1;
	child1.reserve( firstChromosome1.size() + secondChromosome1.size() ); // preallocate memory
	child1.insert( child1.end(), firstChromosome1.begin(), firstChromosome1.end() );
	child1.insert( child1.end(), secondChromosome1.begin(), secondChromosome1.end() );

	result.push_back(child1);

	vector<int>::const_iterator first1_1 = chromosomes[idx2].begin();
	vector<int>::const_iterator last1_1 = chromosomes[idx2].begin() + randNum;
	vector<int> firstChromosome2(first1_1, last1_1);
	
	vector<int>::const_iterator first2_1 = chromosomes[idx1].begin() +randNum;
	vector<int>::const_iterator last2_1 = chromosomes[idx1].end();
	vector<int> secondChromosome2(first2_1, last2_1);
	
	vector<int> child2;
	child2.reserve( firstChromosome2.size() + secondChromosome2.size() ); // preallocate memory
	child2.insert( child2.end(), firstChromosome2.begin(), firstChromosome2.end() );
	child2.insert( child2.end(), secondChromosome2.begin(), secondChromosome2.end() );
	
	result.push_back(child2);

	return result;

}

int cal_fitness(int chroIdx)
{

	int num_of_indanger_pairs=0;
	
	for(int i=0;i<Graph.size();i++)
	{
		for(int j=0;j<Graph[i].size();j++)
		{
			if(chromosomes[chroIdx][i] == chromosomes[chroIdx][Graph[i][j]-1])
			{
				num_of_indanger_pairs++;
			}

			
		}
	}
	cout<<num_of_indanger_pairs/2<<endl;

	return (total_num_of_pairs-num_of_indanger_pairs)/2;
}

void fitness_fn()
{
	for(int i=0;i<fitness_val.size();i++)
	{
		fitness_val[i]=cal_fitness(i);
	}
}

string int_to_string(int num)
{

	stringstream ss;
	ss << num;
	return ss.str();

}

void generate_init_chromosomes()
{
	int j=1;
	srand(time(NULL));
	for(int i=0;i<num_of_chromosomes;i++)
	{
		vector <int> tmp;
		int randNum;

		/* initialize random seed: */
	
		

		for(int k=0;k<Graph.size();k++){

			
			 	randNum=rand() % num_of_encasement + 1;
	
			 	tmp.push_back(randNum);
		
				//tmp.push_back(j);
	
	
			
		}
		j++;
		chromosomes.push_back(tmp);
		fitness_val.push_back(0);
	}
}

vector <int> generate_monotonous_chromosome(int j){
	vector <int> tmp;
	for(int i=0;i<num_of_chromosomes;i++){
		tmp.push_back(j);
	}
	return tmp;
}

vector<int> generate_random_vector(int min,int max)
{

	vector <int> numbers;
	for(int i=min;i<=max;i++){
		numbers.push_back(i);
	}
	std::random_shuffle ( numbers.begin(), numbers.end() );
	return numbers;
	/*string str="";
	for(int i=0;i<numbers.size();i++){
		str=str+int_to_string(numbers[i]);
		if(i!=numbers.size()-1)
			str=str+" ";
	}
	return str;*/
}
/*vector<int> generate_random_chromosome()
{

	vector <int> tmp;
	int randNum;

	 initialize random seed: 
	srand(time(NULL));
	randNurand()%init_randomness + 1;
	
	srand (randNum);

	for(int i=0;i<Graph.size();i++){
		randNum=rand() % num_of_encasement + 1;
	
		tmp.push_back(randNum);
	}
	
	return tmp;
}*/


void print_vec_2dim(vector <vector<int> > vec)
{
	cout<<"__________________"<<endl;
	for(int i=0;i<vec.size();i++){
		for(int j=0;j<vec[i].size();j++){
			cout<<vec[i][j]<<" ";
		}
		cout<<endl;
	}
	cout<<"__________________"<<endl;
}

void print_vec(vector <int> vec)
{
	cout<<"__________________"<<endl;
	for(int i=0;i<vec.size();i++){
		
			cout<<vec[i]<<" ";
	}
	cout<<endl;
	cout<<"__________________"<<endl;			
}
void get_graph()
{
	std::ifstream dataset("Dataset.txt");
	string line;
	while (std::getline(dataset, line))
	{

		for (int i=0; i<line.length(); i++)
		{
		    if (line[i] == ',')
		        line[i] = ' ';
		}
		vector <int> tmpVec;
	    stringstream ss(line);
		int temp;
		while (ss >> temp)
			tmpVec.push_back(temp);
		tmpVec.erase( tmpVec.begin() );
		total_num_of_pairs+=tmpVec.size();
		Graph.push_back(tmpVec);
	}
	total_num_of_pairs=total_num_of_pairs/2;
	


}